﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberVowelGameReloaded
{
    public class NumLetterModel
    {
        string nummerletter;
        string bovenOfOnder;

        public string Nummerletter
        {
            get
            {
                return nummerletter;
            }
            set
            {
                nummerletter = value;
            }
        }
        public string BovenOfOnder
        {
            get
            {
                return bovenOfOnder;
            }
            set
            {
                bovenOfOnder = value;
            }
        }

        

    }
}
